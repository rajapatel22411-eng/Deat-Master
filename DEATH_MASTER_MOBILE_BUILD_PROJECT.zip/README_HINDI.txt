DEATH MASTER - Android Studio Project
Target device: Vivo Y17 (model 1901), Android 11

IMPORTANT:
- This is a starter Android app project, not a built APK.
- It provides safe shortcuts to Android settings and practical gaming tips.
- It does NOT claim zero lag, zero heat, or guaranteed FPS gains.
- Android does not allow ordinary apps to forcibly clear other apps' RAM or control CPU/GPU clocks without privileged/root access.

APK banane ke steps:
1. Computer par Android Studio install karo.
2. Android Studio > Open > is ZIP ko extract karke DeathMaster folder select karo.
3. Gradle sync complete hone do.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK app/build/outputs/apk/debug/app-debug.apk mein milegi.
6. APK ko apne Vivo Y17 mein transfer karke install karo. Unknown-app install permission Android khud maangega.

Agar Android Studio Gradle/JDK version error de, Android Studio ke recommended JDK (17) ko select karo.

PHONE-ONLY BUILD OPTION (GitHub Actions):
1. Use Chrome to sign in to GitHub and create a new public or private repository named DeathMaster.
2. Extract this ZIP using the phone's Files app.
3. In the repository, use Add file > Upload files. Upload the project contents while preserving folders (including .github/workflows/android.yml).
4. Commit the files to the main branch.
5. Open the repository's Actions tab. The workflow "Build DEATH MASTER APK" will run.
6. When it finishes, open the workflow run and download the artifact named death-master-debug-apk.
7. Extract the downloaded artifact ZIP to get app-debug.apk.
Note: GitHub account and internet access are required. GitHub's mobile web interface can be fiddly; the repository must preserve the folder paths exactly.
